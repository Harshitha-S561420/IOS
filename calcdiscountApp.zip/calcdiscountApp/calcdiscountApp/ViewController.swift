//
//  ViewController.swift
//  calcdiscountApp
//
//  Created by Alapati,Harshitha Chowdary on 9/21/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var Amount: UITextField!
    
    @IBOutlet weak var Discount: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func Calculateprice(_ sender: Any) {
        var input = Double(Amount.text!) ?? 0
        var input1 = Double(Discount.text!) ?? 0
        var Discount = (input1 / input) * 100
        var Result1 = input-Discount
        Result.text! = "Discount price is \(Result1)"
    }
    
    @IBOutlet weak var Result: UILabel!
}


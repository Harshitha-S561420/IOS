//
//  ViewController.swift
//  BMICalculator
//
//  Created by Alapati,Harshitha Chowdary on 11/2/23.
//

import UIKit

class ViewController: UIViewController {
    
    var TotalBMI = 0.0
    var imageName = ""
    
    @IBOutlet weak var WeightOL: UITextField!
    
    
    @IBOutlet weak var HeightOL: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func Calculatebtn(_ sender: UIButton) {
        
        var weight = Double(WeightOL.text!) ?? 0.0
        var height = Double(HeightOL.text!) ?? 0.0
        TotalBMI = (weight / (height * height)) * 703
        if (TotalBMI <= 18.4){
            imageName = "Underweight"
            
        }
        else if (TotalBMI>18.5 || TotalBMI<24.9){
            imageName = "Normal"
        }
        else if (TotalBMI>25.0 || TotalBMI<39.9){
            imageName = "0verweight"
        }
        else{
            imageName = "Obesity"
            
        }
    }
    
    
    
    
    
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        if transition == "BMIResult"{
            var destination = segue.destination as! Resultviewcontroller
            destination.bmilb = WeightOL.text!
            destination.bmiheight = HeightOL.text!
            destination.bmi = String(TotalBMI)
            destination.image = imageName
            
            
            
        }
        
    }
    
}

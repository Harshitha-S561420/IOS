//
//  Resultviewcontroller.swift
//  BMICalculator
//
//  Created by Alapati,Harshitha Chowdary on 11/2/23.
//

import UIKit

class Resultviewcontroller: UIViewController {
    
    
    
    @IBOutlet weak var displayweightOL: UILabel!
    
    
    
    @IBOutlet var displayheightOL: UIView!
    
    
    @IBOutlet weak var BMIaftercalculate: UILabel!
    
    
    @IBOutlet weak var ImageOL: UIImageView!
    
    
    var bmilb = ""
    var bmiheight = ""
    var bmi = ""
    var image = ""
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

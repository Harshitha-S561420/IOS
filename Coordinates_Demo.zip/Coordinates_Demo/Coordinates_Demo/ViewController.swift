//
//  ViewController.swift
//  Coordinates_Demo
//
//  Created by Harshitha Alapati on 10/17/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    
    @IBOutlet weak var ImageViewOL: UIImageView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let minX = ImageViewOL.frame.minX
        let minY = ImageViewOL.frame.minY
        
        print(minX,", ",minY)
        
        let maxX = ImageViewOL.frame.minX
        let maxY = ImageViewOL.frame.minY
        
        print(maxX,", ",maxY)
        
        let midX = ImageViewOL.frame.minX
        let midY = ImageViewOL.frame.minY
        
        print(midX,", ",midY)
        
        //Display the image view at the top left corner of the view
        
        ImageViewOL.frame.origin.x = 0
        ImageViewOL.frame.origin.y = 0
        
        
        //Display the image at the top right corner of the view
        
        ImageViewOL.frame.origin.x = 293
        ImageViewOL.frame.origin.y = 0
        
        //Display the image at the bottom right corner of the view
                ImageViewOL.frame.origin.x = 314
                ImageViewOL.frame.origin.y = 796
                
                //Display the image at the bottom left corner of the view
                ImageViewOL.frame.origin.x = 0
                ImageViewOL.frame.origin.y = 752
                
                //Display the image at the center of the view
                //(314/2-50,896/22-50)
                ImageViewOL.frame.origin.x = 157
                ImageViewOL.frame.origin.y = 398

        
        
    }


}


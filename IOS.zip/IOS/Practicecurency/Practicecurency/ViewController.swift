//
//  ViewController.swift
//  Practicecurency
//
//  Created by Harshitha Alapati on 10/4/23.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var inputOL: UITextField!
    
    
    @IBAction func Usdbutton(_ sender: UIButton) {
        var currency : Double = 0.0
        currency = Double(inputOL.text!) ?? 0
        if(currency == 0){
            Imageview.image = UIImage(named: "USD" )
            Displaylabel.text! = "cannot conveert"
        }
        else if(currency.isNaN){
            Imageview.image = UIImage(named: "USD" )
            Displaylabel.text! = "cannot conveert"
        }
        else{
            Imageview.image = UIImage(named: "USD" )
            var cur = String(format: "%.2f",Double(currency)/83.0)
            Displaylabel.text = "\(currency) in usd: \(cur)"
        }

            
    }
    
    
    @IBAction func Cadbutton(_ sender: UIButton) {
        var currency1 : Double = 0.0
        currency1 = Double(inputOL.text!) ?? 0
        if(currency1 == 0){
            Imageview.image = UIImage(named: "CAN")
            Displaylabel.text! = "cannot conveert"
            
        }
        else if(currency1.isNaN){
            Imageview.image = UIImage(named: "CAN" )
            Displaylabel.text! = "cannot conveert"
        }
        else{
            Imageview.image = UIImage(named: "CAN" )
            var cur = String(format: "%.2f",Double(currency1)/82.93 * 1.26)
            Displaylabel.text = "\(currency1) in usd: \(cur)"
        }
        
        
    }
    
    
    @IBOutlet weak var Imageview: UIImageView!
    
    @IBOutlet weak var Displaylabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}


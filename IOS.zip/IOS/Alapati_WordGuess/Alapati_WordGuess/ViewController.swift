//
//  ViewController.swift
//  Alapati_WordGuess
//
//  Created by Harshitha Alapati on 10/17/23.
//

import UIKit

class ViewController: UIViewController {
    

    
    @IBOutlet weak var wordsGuessedLabel: UILabel!
    
    
    @IBOutlet weak var wordsRemainingLabel: UILabel!
    
    
    @IBOutlet weak var totalWordsLabel: UILabel!
    
    
    @IBOutlet weak var userGuessLabel: UILabel!
    
    
    @IBOutlet weak var guessLetterField: UITextField!
    
    
    
    @IBAction func GuessALetter(_ sender: UITextField) {
        var text = guessLetterField.text!
        
        text = String(text.last ?? " ").trimmingCharacters(in: .whitespaces)
        
        guessLetterField.text = text
        
        if text.isEmpty{
            GuessLetter.isEnabled = false
        }
        else{
            GuessLetter.isEnabled = true
        }
    }
    
    
    @IBOutlet weak var hintLabel: UILabel!
    
    
    @IBAction func guessLetterButtonPressed(_ sender: UIButton) {
        let letter = guessLetterField.text!
          
        w+=1
        
        guessCountLabel.isEnabled = true
        letters = letters + letter
        hintLabel.isHidden = false
        hintLabel.isEnabled = true
        guessCountLabel.isHidden = false
            var revealedWord = ""
             for i in word{
                 if(!(letters.contains(i.uppercased()))){
                     revealedWord += "_ "
                     
                 }
                 else{
                     revealedWord += "\(i.uppercased())"
                 }
             }
        guessCountLabel.text = "You have made \(w) guesses"
             
             userGuessLabel.text = revealedWord
             guessLetterField.text = ""
             if userGuessLabel.text!.contains("_") == false{
                 PlayAgain.isHidden = false
                 displayImage.image = UIImage(named: array[c][2])
                 guessCountLabel.text = "Wow! You have made \(w) guesses to guess the word!"
                 c+=1
                 //print(c)
                 let a = array.count-c
                 wordsGuessedLabel.text = ""
                 wordsGuessedLabel.text! = "Total number of words guessed successfully: \(c)"
                 wordsRemainingLabel.text = "Total number of words remaining in game: \(a)"
                 GuessLetter.isEnabled = false;
                 c-=1
             }
        
        if(w == maxNumOfWrongGuesses){
            guessCountLabel.text = "You have used all the available guesses, Please play again"
            GuessLetter.isEnabled = false
            hintLabel.isHidden = true
            c-=1
            PlayAgain.isHidden = false
            PlayAgain.isEnabled = true
            
        }
        GuessLetter.isEnabled = false
       
        
    }
    
    @IBOutlet weak var guessCountLabel: UILabel!
    
    @IBOutlet weak var statusLabel: UILabel!
    
    
    @IBAction func playAgainButtonPressed(_ sender: UIButton) {
        var val : Int = 0
        w = 0
        c+=1
        let r = array.count - c
        userGuessLabel.isHidden = false
        userGuessLabel.isEnabled = true
        statusLabel.isHidden = true
        PlayAgain.isEnabled = true
        displayImage.image = UIImage()
        letters = ""
        hintLabel.isHidden = false
        guessCountLabel.text = "You have made \(w) guesses"
        val = c
        wordsGuessedLabel.text! += "\(val)"
        //print(c)
        //print(wordsGuessedLabel.text!)
        wordsRemainingLabel.text = "Total number of words remaining in game: \(r)"
        
        
        if c==array.count{
            statusLabel.isHidden = false
            statusLabel.text = "Congratulations! You are done! Please start over again"
          //  displayImage.image
            guessCountLabel.isHidden = true
            //wordsGuessedLabel.text! = 0
            displayImage.image = UIImage(named: "Alldone")
             c = -1
            userGuessLabel.isHidden = true
            hintLabel.isHidden = true
            wordsGuessedLabel.text! = "Total number of words guessed successfully: \(c+1)"
            wordsRemainingLabel.text = "Total number of words remaining in game: \(array.count)"
            
        }
        else{
            word = array[c][0]
            
            hintLabel.text = "Hint: " + array[c][1]
            
            GuessLetter.isEnabled = true
            
            wordGuessMethod()
            
            PlayAgain.isHidden = true
        }
    }
    
    
    @IBOutlet weak var PlayAgain: UIButton!
    
    
    @IBOutlet weak var GuessLetter: UIButton!
    let array = [["Swift","Programming Language","Swift"],
                 ["BMW","Car","BMW"],
                 ["Dog","pet","Dog"],
                 ["Burger","Food","Burger"],
                 ["iPhone","Cool Mobile","Iphone"]]
    var word = ""
    var c = 0
    var letters = ""
    var maxNumOfWrongGuesses = 10
    var w = 0
    
    func wordGuessMethod() {
        userGuessLabel.text = ""
        for _ in word{

            userGuessLabel.text! += "_ "
        }
        
    }
    
    @IBOutlet weak var displayImage: UIImageView!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        totalWordsLabel.text! += "\(array.count)"
        wordsRemainingLabel.text! += "\(array.count-c)"
        wordsGuessedLabel.text! += "\(c)"
        
        GuessLetter.isEnabled = false
        
        word = array[c][0]
        
        hintLabel.text = "Hint: "+array[c][1]
        
        wordGuessMethod();
        
        statusLabel.isHidden = true
        
        
        

    }


}


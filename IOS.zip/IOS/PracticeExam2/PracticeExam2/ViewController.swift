//
//  ViewController.swift
//  PracticeExam2
//
//  Created by Harshitha Alapati on 11/13/23.
//

import UIKit

class ViewController: UIViewController {
    
    var img = ""
    
    
    @IBOutlet weak var CourseIdOL: UILabel!
    
    
    @IBOutlet weak var StudrntIdOL: UILabel!
    
    
    @IBOutlet weak var CoursetextOL: UITextField!
    
    
    
    @IBOutlet weak var StudenttextOL: UITextField!
    
    @IBOutlet weak var courseCheckbtn: UIButton!
    
    
    @IBOutlet weak var displayOL: UILabel!
    
    
    @IBOutlet weak var ImageOL: UIImageView!
    
    
    @IBOutlet weak var EnrollCoursebtn: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    courseCheckbtn.isHidden = true
    }

   
    
    @IBAction func textEntered(_ sender: UITextField) {
        print("dfghj")
        if(self.CoursetextOL.state.isEmpty){
            courseCheckbtn.isHidden = true
        }
        else{
            courseCheckbtn.isHidden = false
        }
    }
    
    
    @IBAction func textEntered2(_ sender: UITextField) {
        print("qwe")
        if(self.CoursetextOL.state.isEmpty){
            courseCheckbtn.isHidden = true
        }
        else{
            courseCheckbtn.isHidden = false
        }
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            let transition = segue.identifier

            if transition == "ResultSegue"{
                let destination = segue.destination as! ResultViewController
                destination.destImg = img
            }

        }

    
}


//
//  ViewController.swift
//  practice
//
//  Created by Harshitha Alapati on 10/4/23.
//

import UIKit

class ViewController: UIViewController {
    
    var bmi=0.0
    @IBOutlet weak var Name: UITextField!
    
    
    @IBOutlet weak var AgeOL: UITextField!
    

    @IBOutlet weak var LnameOL: UITextField!
    
    
    @IBAction func calculateAge(_ sender: UIButton) {
        
        if(bmi < 18.5){
            Imageview.image = UIImage(named: "underWeight")
        }
        
        
    }
    
    
    @IBOutlet weak var Imageview: UIImageView!
    
    @IBOutlet weak var displaylabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        Imageview.image = UIImage(named: "noResults")
    }


}


//
//  ViewController.swift
//  Alapati_Movies
//
//  Created by Harshitha Alapati on 11/26/23.
//

import UIKit

class GenreViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return genreArray.count
    }
    
    var genreArray = gArray
    override func viewDidLoad() {
        super.viewDidLoad()
        genreTableView.dataSource = self
        genreTableView.delegate = self
        self.title = "Movies App"
        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = genreTableView.dequeueReusableCell(withIdentifier:  "sectionCell", for: indexPath)
  
        cell.textLabel?.text = genreArray[indexPath.row].category
        return cell
    }
    
    
    @IBOutlet weak var genreTableView: UITableView!
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let transition = segue.identifier
        if(transition=="movieSegue"){
            let destination = segue.destination as! MoviesViewController
            destination.desMovies = genreArray[(genreTableView.indexPathForSelectedRow?.row)!]
            
//            var genreArray = gArray
          
            
            
        }
        
    }
}

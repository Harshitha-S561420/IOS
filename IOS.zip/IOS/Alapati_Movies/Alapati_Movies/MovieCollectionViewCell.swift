//
//  MovieCollectionViewCell.swift
//  Alapati_Movies
//
//  Created by Harshitha Alapati on 11/26/23.
//

import UIKit
class MovieCollectionViewCell: UICollectionViewCell {
    
    

    @IBOutlet weak var Movieimg: UIImageView!
    func assignMovies(movie: Movie){
        Movieimg.image = movie.image
    }
    
}

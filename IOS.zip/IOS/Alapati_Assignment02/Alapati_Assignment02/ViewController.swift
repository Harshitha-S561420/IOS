//
//  ViewController.swift
//  Alapati_Assignment02
//
//  Created by Harshitha Alapati on 9/13/23.
//

import UIKit

class ViewController: UIViewController {


    
    @IBOutlet weak var nameOutlet: UITextField!
    
    @IBOutlet weak var billAmountOutlet: UITextField!
    
  @IBOutlet weak var tipPercentageOutlet: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    
    @IBOutlet weak var nameLabel: UILabel!
    
    
    @IBOutlet weak var billAmountLabel: UILabel!
    
    
    @IBOutlet weak var tipAmountLabel: UILabel!
    
    
    @IBOutlet weak var totalAmountLabel: UILabel!
    

    @IBAction func SubmitBTN(_ sender: UIButton) {
        let name = nameOutlet.text!
        let bill = Double(billAmountOutlet.text!) ?? 0
        let tip = Double(tipPercentageOutlet.text!) ?? 0
        var cal_tip_amount = (bill * tip )/100
        var bill_amount = (bill + cal_tip_amount)
        nameLabel.text! = "Name: \(name)"
        billAmountLabel.text! = "Bill Amount: $\(bill)"
                tipAmountLabel.text! = String(format: "Tip Amount: $%.2f", cal_tip_amount)
                totalAmountLabel.text! = String(format:"Total Amount: $%.2f", bill_amount)

    }
    @IBAction func ResetBTN(_ sender: UIButton) {
        nameOutlet.text! = ""
        billAmountLabel.text! = ""
        billAmountOutlet.text! = ""
        tipAmountLabel.text! = ""
        tipPercentageOutlet.text! = ""
        totalAmountLabel.text! = ""
        nameLabel.text! = ""
        billAmountLabel.text! = ""
        tipAmountLabel.text! = ""
        totalAmountLabel.text! = ""
    }

}


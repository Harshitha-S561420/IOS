//
//  Student Detail ViewController.swift
//  StudentApp
//
//  Created by Alapati,Harshitha Chowdary on 11/7/23.
//

import UIKit

class Student_Detail_ViewController: UIViewController {

    @IBOutlet weak var Label1OL: UILabel!
    
    
    @IBOutlet weak var Label2OL: UILabel!
    
    
    @IBOutlet weak var Label3OL: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    
    @IBAction func Viewcoursesbtn(_ sender: Any) {
        
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

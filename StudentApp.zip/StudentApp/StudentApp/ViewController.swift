//
//  ViewController.swift
//  StudentApp
//
//  Created by Alapati,Harshitha Chowdary on 11/7/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var SidOL: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func Getdetails(_ sender: Any) {
        
    }
}

